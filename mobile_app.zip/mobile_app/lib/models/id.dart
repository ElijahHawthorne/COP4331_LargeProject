double id = 0;
String firstName = '';
String lastName = '';
String email = '';
String username = '';
String password = '';